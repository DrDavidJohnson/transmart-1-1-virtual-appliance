keywords <- function( ... )
{
  file <- file.path(R.home("doc"),"KEYWORDS")
  file.show(file, ...)
}
