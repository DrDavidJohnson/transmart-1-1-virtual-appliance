double vMax(double * v, int len);
double vMin(double * v, int len);
double pivot(double * v, int len, double target);
